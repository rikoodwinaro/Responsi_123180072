package com.example.covid19.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.covid19.R;
import com.example.covid19.data.DataItem;
import com.example.covid19.data.service.CovidApi;
import com.example.covid19.data.service.CovidListener;
import com.example.covid19.ui.adapter.RsAdapter;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;

public class RsActivity extends AppCompatActivity {

    private RecyclerView rvRumahSakit;
    private RsAdapter rsAdapter;
    BottomNavigationView menu;

    CovidListener<ArrayList<DataItem>> listRsListener = new CovidListener<ArrayList<DataItem>>() {
        @Override
        public void onSuccess(ArrayList<DataItem> body) {
            rsAdapter.setDataRs(body);
        }

        @Override
        public void onFailed(String message) {

        }
    };

    @Override
    protected void onCreate(Bundle savedInstaceState){
        super.onCreate(savedInstaceState);
        setContentView(R.layout.activity_rs);
        rvRumahSakit = rvRumahSakit.findViewById(R.id.rv_rumahsakit);
        menu = menu.findViewById(R.id.bottom_navigation);

        rvRumahSakit.setLayoutManager(new LinearLayoutManager(this));
        rvRumahSakit.setHasFixedSize(true);
        rvRumahSakit.setAdapter(rsAdapter);
        rvRumahSakit.setLayoutManager(new LinearLayoutManager(this));

        menu.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull @NotNull MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.kasus_covid:
                        Intent home = new Intent(RsActivity.this, MainActivity.class);
                        startActivity(home);
                        finish();
                        break;
                    case R.id.rs_rujukan:
                        Intent rs = new Intent(RsActivity.this, RsActivity.class);
                        startActivity(rs);
                        finish();
                        break;
                }
                return true;
            }
        });

        CovidApi covidApi = new CovidApi();
        covidApi.getFaskes(listRsListener);

    }
}
