package com.example.covid19.ui.adapter;

import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.covid19.R;
import com.example.covid19.data.DataItem;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;

public class RsAdapter extends RecyclerView.Adapter<RsAdapter.ViewHolder> {
    private ArrayList<DataItem> dataRs = new ArrayList<>();

    public void setDataRs(ArrayList<DataItem> body){
        this.dataRs.clear();
        this.dataRs.addAll(dataRs);

        notifyDataSetChanged();
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull @NotNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.data_rumahsakit, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull @NotNull ViewHolder holder, int position) {
        holder.bind(dataRs.get(position));

    }

    @Override
    public int getItemCount() {
        return dataRs.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private TextView nama_rs, alamat;
        private Button maps;
        public ViewHolder(@NonNull @NotNull View itemView) {
            super(itemView);
            nama_rs = itemView.findViewById(R.id.tv_rumahsakit);
            alamat = itemView.findViewById(R.id.tv_alamat);
            maps = itemView.findViewById(R.id.btn_maps);
        }

        public void bind(DataItem dataItem) {
            nama_rs.setText(dataItem.getNama());
            alamat.setText(dataItem.getAlamat());

            maps.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Uri intent = Uri.parse("rs: " + dataItem.getLatitude() + "," +dataItem.getLongitude() + "?q=" + Uri.encode(dataItem.getNama()));
                    Intent maps = new Intent(Intent.ACTION_VIEW, intent);
                    maps.setPackage("com.google.apps.maps");
                    itemView.getContext().startActivity(maps);
                }
            });
        }
    }
}
